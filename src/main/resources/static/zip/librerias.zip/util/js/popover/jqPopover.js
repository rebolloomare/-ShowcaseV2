/**
 * Funcion para inicializar el widget
 * Popover
 */

function creaPopover(){
	"use strict";
	
	$('[data-toggle="popover"]').popover();
}