/**
 * Funcion de inicializacion del widget
 * Tooltip
 */

function creaTooltip(){
	"use strict";
	
	$('[data-toggle="tooltip"]').tooltip();
}