
$(document).ready(function(){$(".alert").addClass("in").fadeOut(4500);

/* swap open/close side menu icons */
/*
$("ul.nav > li.nav-header a").click(function() {
	//[data-toggle=collapse]
  	// toggle icon
	console.log("data-toggle click");
  	$(this).find("i").toggleClass("glyphicon-chevron-right glyphicon-chevron-down");
});*/
});
